========= History =========

Version 2.x support S-Cart 6.x
Version 3.x support S-Cart 7.x

========= INSTALL =========

Link plugin: https://s-cart.org/en/plugin/import-multiple-products_162457702460d5140058dbb.html