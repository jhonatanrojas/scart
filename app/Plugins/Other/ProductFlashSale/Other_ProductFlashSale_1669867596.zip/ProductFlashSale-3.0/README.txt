========= History =========

Version 2.x support S-Cart 6.x

Version 3.x support S-Cart 7.x

========= Install =========

Step1:

Import plugin : https://s-cart.org/en/docs/master/how-to-install-module-extension.html#install-plugin-import

Step2:

Copy file views/block/flash_sale.blade.php to folder resources/views/your-teamplate/block/flash_sale.blade.php

Step3:

Admin -> Layyout -> Block content

Add new block with: position = "Bottom", Select page = "Home page", tpye = "View",  Text = "flash_sale", status = checked

Step 4: 

Access yourd-main/sc_admin/productflashsale and config product flash sale

Link: https://s-cart.org/en/plugin/product-flash-sale_162051258960970f4d1cd45.html
